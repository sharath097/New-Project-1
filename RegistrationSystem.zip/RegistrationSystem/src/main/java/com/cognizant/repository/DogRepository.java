package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Dogs;

@Repository
public interface DogRepository extends JpaRepository<Dogs, Integer>{

	@Query("select s from Dogs s where s.dName=(:dName) and s.dPassword=(:dPassword)")
	Dogs findByLoginData(String dName, String dPassword);
}
