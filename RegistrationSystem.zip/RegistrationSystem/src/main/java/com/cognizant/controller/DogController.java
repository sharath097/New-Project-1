package com.cognizant.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.validation.beanvalidation.CustomValidatorBean;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.dao.DogDao;
import com.cognizant.model.Dogs;


@Controller
public class DogController {

	@Autowired
	Dogs dogs;
	
	@Autowired
	DogDao dogDao;
	
String msg;
	
	
	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("dogs", dogs);
		model.addAttribute("msg", msg);
		return "index";
	}
	@RequestMapping("logout")
	public String logout(Model model) {
		model.addAttribute("dogs", dogs);
		msg="Thank You, Visit Again";
		model.addAttribute("msg", msg);
		return "index";
	}

	@RequestMapping("validate")
	public String validateUser(@ModelAttribute("dogs") Dogs dogs, Model mv) {

		Dogs student1 = dogDao.validateDog(dogs);
		
		if (student1 != null) {
			
			System.out.println("Login Successfull");
			
			
			
			return "redirect:/homepage";
		} else {
			System.out.println("Login Failed");
			msg = "Login Failed";
			return "redirect:/";
		}

	}

	@RequestMapping("/homepage")
	public String showHomePage(Model model) {
		model.addAttribute("dogs", dogs);
		return "homepage";
	}
	@RequestMapping("/registeration")
	public String showRegisterationForm(Model model) {
		model.addAttribute("dogs", dogs);
		return "registeration";
	}

	@RequestMapping("submitform")
	public ModelAndView saveDog(@ModelAttribute("dogs") Dogs dogs, ModelAndView mv,
			@RequestParam("pic") MultipartFile file) throws IOException {

		System.out.println("In Save Dogs");
		byte[] studentPic = file.getBytes();
		dogs.setDogPic(studentPic);
		dogDao.addDog(dogs);
		mv.addObject("msg", "Dog Added Successfully");
		mv.setViewName("registeration");
		return mv;
	}

	@RequestMapping("getalldogs")
	public ModelAndView getAllStudents(ModelAndView mv) {
		List<Dogs> studentList = dogDao.getAllDogs();
		mv.addObject("dogs", studentList);
		mv.addObject("msg", msg);
		mv.setViewName("viewdogs");
		return mv;
	}

	@RequestMapping("getdogform")
	public String getDogForm() {
		return "getdogs";
	}

	@RequestMapping("getbydogid")
	public ModelAndView getById(@RequestParam("dogId") int dogId, ModelAndView mv) {
		Dogs dogs = dogDao.getDogById(dogId);
		mv.addObject("dogs", dogs);
		mv.setViewName("showdogs");
		return mv;
	}

	@RequestMapping("updatedogs/{dogId}")
	public String getUpdateStudent(@PathVariable int dogId, Model m) {

		Dogs dogs = dogDao.getDogById(dogId);
		System.out.println("In Controller : " + dogs);
		 m.addAttribute("dogs", dogs);
		return "updatedogs";

	}
	
	@RequestMapping("saveupdate")
	public String saveUpdate(@ModelAttribute("dogs") Dogs dogs,
			@RequestParam("pic") MultipartFile file) throws IOException {
		byte[] studentPic = file.getBytes();
		dogs.setDogPic(studentPic);
		dogDao.updateDog(dogs);
		msg="Dogs Details Updated successfully";
		return "redirect:/getalldogs";

	}

	@RequestMapping("deletedog/{dogId}")
	public String deleteStudent(@PathVariable int dogId) {
		dogDao.deleteDog(dogId);
		return "redirect:/getalldogs";
	}
}

