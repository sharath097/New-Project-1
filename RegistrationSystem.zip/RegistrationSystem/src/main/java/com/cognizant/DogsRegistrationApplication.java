package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogsRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogsRegistrationApplication.class, args);
	}

}
